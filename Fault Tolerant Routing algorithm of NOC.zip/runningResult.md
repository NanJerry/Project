1 cycle = $1000\ \ ps$ = $10^{-9} s$ = $1 \ ns$

Received Ratio (in a fixed time) = #Received Flits/(package_injected_rate * (min_package_size + max_package_size)/2 * (#simulation_cycles - #warm_up_cycles) * (mesh_x_size * mesh_y_size))

### Up-down algorithm

#### Latency vs Accepted traffic

* random

  Running in configuration: simulation cycle: 20000, warm up cycle(the cycle that does not record into our statistics): 3000

  | Rate  | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput  | Average IP throughput    |
  | ----- | ----------------------------- | ------------------------------- | ------------------- | ------------------------ |
  | 0.001 | 1766.77 ns                    | 0.5771                          | 1.733 (flits/cycle) | 0.006926(flits/cycle/IP) |
  | 0.005 | 6558.8 ns                     | 0.1115                          | 1.713               | 0.00669                  |
  | 0.010 | 7785.7 ns                     | 0.0549                          | 1.687               | 0.00659                  |
  | 0.015 | 8796.0 ns                     | 0.0366                          | 1.686               | 0.00659                  |
  | 0.020 | 9491.4 ns                     | 0.0283                          | 1.739               | 0.00654                  |
  | 0.025 | 10098.1 ns                    | 0.0213                          | 1.642               | 0.00641                  |
  | 0.030 | 10022.6 ns                    | 0.0186                          | 1.71141             | 0.00669                  |
  | 0.035 | 10446.9 ns                    | 0.0158                          | 1.696               | 0.00663                  |
  | 0.040 | 10490.3 ns                    | 0.0134                          | 1.646               | 0.0064                   |
  | 0.050 | 10654.1 ns                    | 0.0112                          | 1.724               | 0.0067                   |

* bit-reversal 

  

  | Rate  | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | 0.001 | 1315.88 ns                    | 0.629                           | 1.933              | 0.00755               |
  | 0.005 | 3417.63 ns                    | 0.176                           | 2.701              | 0.01055               |
  | 0.010 | 2849.07 ns                    | 0.121                           | 3.713              | 0.01450               |
  | 0.015 | 2658.51 ns                    | 0.101                           | 4.657              | 0.01819               |
  | 0.020 | 2273.96                       | 0.092                           | 5.629              | 0.02199               |
  | 0.025 | 2311.16                       | 0.086                           | 6.575              | 0.02568               |
  | 0.030 | 2225.88                       | 0.081                           | 7.473              | 0.02919               |
  | 0.035 | 2143.75                       | 0.077                           | 8.320              | 0.03250               |
  | 0.040 | 2230.83                       | 0.074                           | 9.110              | 0.03559               |
  | 0.050 | 3541.27                       | 0.060                           | 9.281              | 0.03625               |
  | 0.100 | 7501.34                       | 0.030                           | 9.337              | 0.03647               |
  | 0.150 | 8856.71                       | 0.020                           | 9.359              | 0.03656               |

* table-based 

  | Rate  | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | 0.001 |                               |                                 |                    |                       |
  | 0.005 |                               |                                 |                    |                       |
  | 0.010 |                               |                                 |                    |                       |
  | 0.015 |                               |                                 |                    |                       |
  | 0.020 |                               |                                 |                    |                       |
  | 0.025 |                               |                                 |                    |                       |
  | 0.030 |                               |                                 |                    |                       |
  | 0.035 |                               |                                 |                    |                       |
  | 0.040 |                               |                                 |                    |                       |
  | 0.050 |                               |                                 |                    |                       |

#### Latency vs fault rate

Injected rate: 0.05

* random

  | Fault | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | +10   | 10377.4                       | 0.0120                          | 1.84               | 0.007205              |
  | +20   | 10691.6                       | 0.01                            | 1.533              | 0.005988              |
  | +30   | 10805.3                       | 0.0092                          | 1.422              | 0.0055538             |
  | +40   | 10610.8                       | 0.0096                          | 1.475              | 0.0057631             |

* bit-reversal

  | Fault | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | +10   | 6806.2                        | 0.0284                          | 4.368              | 0.01706               |
  | +20   | 5944.07                       | 0.0296                          | 4.55               | 0.01778               |
  | +30   | 6027.71                       | 0.0260                          | 3.987              | 0.01557               |
  | +40   | 6893.69                       | 0.0221                          | 3.393              | 0.01325               |
  
* table-based 

  | Fault | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | +10   |                               |                                 |                    |                       |
  | +20   |                               |                                 |                    |                       |
  | +30   |                               |                                 |                    |                       |
  | +40   |                               |                                 |                    |                       |

### State-machine algorithm

#### Latency vs Accepted traffic

* random

  Running in configuration: simulation cycle: 20000, warm up cycle(the cycle that does not record into our statistics): 3000

  | Rate  | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | 0.001 | 18.244                        | 0.0104                          | 18.2444            | 0.0318                |
  | 0.005 | 0                             | 0                               | 0                  | 0                     |
  | 0.010 | 0                             | 0                               | 0                  | 0                     |
  | 0.015 | 0                             | 0                               | 0                  | 0                     |
  | 0.020 | 0                             | 0                               | 0                  | 0                     |
  | 0.025 | 0                             | 0                               | 0                  | 0                     |
  | 0.030 | 0                             | 0                               | 0                  | 0                     |
  | 0.035 | 0                             | 0                               | 0                  | 0                     |
  | 0.040 | 0                             | 0                               | 0                  | 0                     |
  | 0.050 | 0                             | 0                               | 0                  | 0                     |

* bit-reversal

  | Rate  | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | 0.001 | 18.76 ns                      | 0.128                           | 0.394              | 0.00153               |
  | 0.005 | 4.31 ns                       | 0.053                           | 0.824              | 0.00322               |
  | 0.010 | 31.53                         | 0.084                           | 2.588              | 0.01011               |
  | 0.015 | 24.50                         | 0.0353                          | 1.629              | 0.00636               |
  | 0.020 | 1346.03                       | 0.0326                          | 2.001              | 0.00782               |
  | 0.025 | 1768.28                       | 0.0386                          | 2.963              | 0.01158               |
  | 0.030 | 2835.23                       | 0.0426                          | 3.926              | 0.01533               |
  | 0.035 | 2876.78                       | 0.0309                          | 3.318              | 0.01296               |
  | 0.040 | 431.126                       | 0.0200                          | 2.460              | 0.00961               |
  | 0.050 | 3202.72                       | 0.0212                          | 3.262              | 0.01277               |

* table-based 

  | Rate  | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | 0.001 |                               |                                 |                    |                       |
  | 0.005 |                               |                                 |                    |                       |
  | 0.010 |                               |                                 |                    |                       |
  | 0.015 |                               |                                 |                    |                       |
  | 0.020 |                               |                                 |                    |                       |
  | 0.025 |                               |                                 |                    |                       |
  | 0.030 |                               |                                 |                    |                       |
  | 0.035 |                               |                                 |                    |                       |
  | 0.040 |                               |                                 |                    |                       |
  | 0.050 |                               |                                 |                    |                       |

#### Latency vs fault rate

* random

  | Fault | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | +10   |                               |                                 |                    |                       |
  | +20   |                               |                                 |                    |                       |
  | +30   |                               |                                 |                    |                       |
  | +40   |                               |                                 |                    |                       |
  
* bit-reversal

  | Fault | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | +10   |                               |                                 |                    |                       |
  | +20   |                               |                                 |                    |                       |
  | +30   |                               |                                 |                    |                       |
  | +40   |                               |                                 |                    |                       |
  
* table-based 

  | Fault | Latency/Average delay(cycles) | Received Ratio(in a fixed time) | Network throughput | Average IP throughput |
  | ----- | ----------------------------- | ------------------------------- | ------------------ | --------------------- |
  | +10   |                               |                                 |                    |                       |
  | +20   |                               |                                 |                    |                       |
  | +30   |                               |                                 |                    |                       |
  | +40   |                               |                                 |                    |                       |

