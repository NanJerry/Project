### Architecture Conference

* ISCA = International Symposium on Computer Architecture
* ASPLOS = Arch. Support for Programming Languages and OS
* MICRO = International Symposium on Microarchitecture (!!!)
* HPCA = High Performance Computer Architecture
* SPAA = Symposium on Parallel Algorithms and Architecture
* ICS = International Conference on Supercomputing
* PACT = Parallel Architectures and Compilation Techniques
* https://www.es.ele.tue.nl/~heco/lit/conf+journals.html

### On-chip Network Design

1. Conference worth looking
   * NOCS: International Symposium on Networks-on-Chip
   * SC Conference on on high performance computing (HPC), networking, storage and analysis
   * ISCA: International Symposium on Computer Architecture
   * DAC: Design Automation Conference

1. On-chip network problem
2. s
3. 